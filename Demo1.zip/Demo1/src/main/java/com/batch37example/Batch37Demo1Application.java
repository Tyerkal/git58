package com.batch37example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch37Demo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Batch37Demo1Application.class, args);
	}

}
